function createjsDOMenu() {
	
}